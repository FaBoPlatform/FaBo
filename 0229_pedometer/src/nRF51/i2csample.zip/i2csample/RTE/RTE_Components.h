
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'i2csample' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define BSP_DEFINES_ONLY
#define UART0_ENABLED

#endif /* RTE_COMPONENTS_H */
