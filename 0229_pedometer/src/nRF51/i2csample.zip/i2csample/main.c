#include "app_trace.h"
#include "app_error.h"
#include "app_twi.h"
#include "app_util_platform.h"
#include "nrf_delay.h"

// I2Cのピン番号
#define I2C_SCL_PIN 7
#define I2C_SDA_PIN 30

// 最大トランザクション数
#define MAX_PENDING_TRANSACTIONS    5

// スレーブアドレス
static uint16_t device_address = 0x53;

// Twiインスタンス
static app_twi_t m_app_twi = APP_TWI_INSTANCE(0);

// Twi初期化
void twi_init (void)
{
	ret_code_t err_code;

	const nrf_drv_twi_config_t twi_config = {
		 .scl                = I2C_SCL_PIN,
		 .sda                = I2C_SDA_PIN,
		 .frequency          = NRF_TWI_FREQ_100K,
		 .interrupt_priority = APP_IRQ_PRIORITY_LOW
	};

	APP_TWI_INIT(&m_app_twi, &twi_config, MAX_PENDING_TRANSACTIONS, err_code);
	APP_ERROR_CHECK(err_code);
}

// 指定レジスタに1Byte書き込む
void twi_write_byte(uint8_t register_address, uint8_t data)
{
	uint8_t buff[] = {register_address, data};
	app_twi_transfer_t const transfers[] = {
		APP_TWI_WRITE(device_address, buff, 2, 0),
	};
	
	APP_ERROR_CHECK(app_twi_perform(&m_app_twi, transfers, 1, NULL));
}

// 指定レジスタを読み込む
void twi_read(uint8_t register_address, char *buff, uint8_t size)
{
	app_twi_transfer_t const transfers[] = {
		APP_TWI_WRITE(device_address, &register_address, 1, APP_TWI_NO_STOP),
		APP_TWI_READ (device_address, buff, size, 0)
	};
	
	APP_ERROR_CHECK(app_twi_perform(&m_app_twi, transfers, 2, NULL));
}

// 指定レジスタを1Byteだけ読み込む
uint8_t twi_read_byte(uint8_t register_address)
{
	char buff = 0;
	twi_read(register_address, &buff, 1);
	return buff;
}

// メイン
int main() {
	app_trace_init();
	printf("start\n");

	twi_init();
	
	// デバイスID確認
	uint8_t dev = twi_read_byte(0x00);
	if (dev == 0xe5) {
		printf("I am ADXL345");
	} else {
		printf("device:%d\n", dev);
		return 0;
	}
	
	// データフォーマットをFULL_RES, r-Justify, +-2gに設定
	twi_write_byte(0x31, 0x0F);
	// 計測モードに設定
	twi_write_byte(0x2d, 0x08);
	
	// 加速度を計測
	char buff[6] = {0};
	while(true) {
		__WFE();
		nrf_delay_ms(500);
		twi_read(0x32, buff, 6);
		short x = buff[1] << 8 | buff[0];
		short y = buff[3] << 8 | buff[2];
		short z = buff[5] << 8 | buff[4];
		printf("x:%d, y:%d, z:%d\n", x, y, z);
	}

}
